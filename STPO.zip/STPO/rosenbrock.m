% Test Function: Rosenbrock Function
function f = rosenbrock(x)
    % This function is the standard Rosenbrock function, with a minimum value of 0 when x = [1, 1].
    f = sum(100 * (x(2:end) - x(1:end-1).^2).^2 + (1 - x(1:end-1)).^2);
end
