% Main function, calling the STPO algorithm for testing
clc;
clear;
close all;

% Set algorithm parameters
N = 30;                % Population size
Max_iter = 100;        % Maximum number of iterations
lb = -5;               % Lower bound of variables
ub = 5;                % Variable Upper Bound
dim = 2;               % Dimension
fobj = @rosenbrock;    % Objective function

% Invoke the STPO algorithm
[Best_score, Best_pos, curve] = STPO(N, Max_iter, lb, ub, dim, fobj);

% Output results
fprintf('Best Score: %.5f\n', Best_score);
disp('Best Position:');
disp(Best_pos);

% Plot the convergence curve
figure;
plot(1:Max_iter, curve, 'LineWidth', 2);
title('Convergence Curve');
xlabel('Iteration');
ylabel('Best Fitness Value');
grid on;


